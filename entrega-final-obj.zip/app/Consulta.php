<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Consulta extends Model
{
    protected $fillable=['nombre', 'email', 'celular', 'mensaje'];
}
