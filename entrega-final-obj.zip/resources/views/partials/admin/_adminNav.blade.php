    <div class="menu-wrapper">
        <div class="menu">
            <!-- Menu Container -->
            <ul>
                <li class="menu-title">Admin Panel</li>
                <li class="has-sub">
                    <a><i class="icon-screen-desktop"></i><span>Dashboard</span><i class="arrow"></i></a></i></a>
                    <ul class="sub-menu">
                        <li>
                            <a href="{{route('consultas')}}"><span>Consultas</span></a>
                        </li>
                        <li>
                            <a href="{{route('productos')}}"><span>Nuevo Producto</span></a>
                        </li>
                        <li>
                            <a href="{{route('viewProductos')}}"><span>Productos</span></a>
                        </li>
                        <li>
                            <a href="{{route('usuarios')}}"><span>Usuarios</span></a>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
