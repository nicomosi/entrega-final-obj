<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Apez Admin Template | Tickets</title>
    <link rel="icon" type="image/x-icon" href="images/favicon.png">

    <!-- Switcher CSS -->
    <link rel="stylesheet" href="{{url('admin/assets/plugin/switchery/switchery.min.css')}}" />
    <!-- Datatables CSS -->
    <link rel="stylesheet" href="{{url('admin/assets/plugin/datatable/datatables.min.css')}}" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="{{url('admin/dist/css/style.css')}}" />
</head>
