<!DOCTYPE html>
<html lang="en">
    
<?php echo $__env->make('partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    

<body>
    <div class="wrapper">
        <!-- Start Header Section -->
        <header class="header-1">
            <div class="hdr-topbar">
                <div class="layer-stretch">
                    <div class="row pt-1 pb-1">
                        <div class="col-md-5">
                            <ul class="social-list social-list-sm">
                                <li>
                                    <a href="#" id="sample-facebook-1"><i class="fab fa-facebook"></i></a>
                                    <span class="mdl-tooltip mdl-tooltip--bottom" data-mdl-for="sample-facebook-1">Facebook</span>
                                </li>

                                <li>
                                    <a href="#" id="sample-instagram-1"><i class="fab fa-instagram"></i></a>
                                    <span class="mdl-tooltip mdl-tooltip--bottom" data-mdl-for="sample-instagram-1">Instagram
                                    </span>
                                </li>
                                <li>
                                    <a href="#" id="sample-youtube-1"><i class="fab fa-youtube"></i></a>
                                    <span class="mdl-tooltip mdl-tooltip--bottom" data-mdl-for="sample-youtube-1">Youtube</span>
                                </li>

                            </ul>
                        </div>
                        <div class="col-md-7 hdr-link text-right">
                            <?php if(auth()->guard()->guest()): ?>
                            <a class="mdl-button mdl-js-button mdl-button--colored mdl-js-ripple-effect button button-white button-sm m-1" href="<?php echo e(route('login')); ?>"><i class="icon-login mr-2"></i>Login</a>
                            
                            <div class="separator"></div>
                                <?php if(Route::has('register')): ?>
                                    <a class="mdl-button mdl-js-button mdl-button--colored mdl-js-ripple-effect button button-white button-sm m-1" href="<?php echo e(route('register')); ?>"><i class="icon-user-follow mr-2"></i>Registro</a>
                                <?php endif; ?>
                                <div class="separator"></div>
                                <?php else: ?>
                                <a class="mdl-button mdl-js-button mdl-button--colored mdl-js-ripple-effect button button-white button-sm m-1" id="my-account"><i class="icon-user-follow mr-2"></i>Mi Cuenta</a>
                                <?php endif; ?>
                            <ul class="mdl-menu mdl-menu--bottom-right mdl-js-menu mdl-js-ripple-effect" data-mdl-for="my-account">

                                <li class="mdl-menu__item">Mi Perfil</li>
                                <li class="mdl-menu__item">Cambiar Contraseña</li>
                                <?php if(auth()->guard()->guest()): ?>

                                <?php else: ?>
                                <?php if(Auth::user()->hasRole('admin') || Auth::user()->hasRole('superAdmin')): ?>
                            <li class="mdl-menu__item"> <a href="<?php echo e(Route('consultas')); ?>">Back Office</a></li>
                                <?php endif; ?>

                                <?php endif; ?>
                                <li class="mdl-menu__item">
                                    <a class="" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Cerrar Sesión')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </li>
                                

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="layer-stretch hdr">
                <div class="tbl">
                    <div class="tbl-row">
                        <!-- Start Header Logo Section -->
                        <div class="tbl-cell hdr-logo">
                            <a href="index.html"><img src="images/logo-black.png" alt=""></a>
                        </div><!-- End Header Logo Section -->
                        <div class="tbl-cell hdr-menu">
                            <!-- Start Menu Section -->
                            <ul class="menu">
                                <li class="menu-megamenu-li">
                                    <a class="mdl-button mdl-js-button mdl-js-ripple-effect" href="<?php echo e(url('/')); ?>">Home</a>
                                </li>
                                <li class="menu-megamenu-li">
                                    <a class="mdl-button mdl-js-button mdl-js-ripple-effect" href="<?php echo e(route('productosShow')); ?>">Viandas</a>
                                </li>
                                <li class="menu-megamenu-li">
                                    <a class="mdl-button mdl-js-button mdl-js-ripple-effect" href="<?php echo e(url('faq')); ?>">Faq</a>
                                </li>
                                <li class="menu-megamenu-li">
                                    <a class="mdl-button mdl-js-button mdl-js-ripple-effect btn" href="#" data-toggle="modal" data-target="#contactPopup">Contacto</a>
                                </li>
                                <li class="menu-megamenu-li">
                                    <a class="mdl-button mdl-js-button mdl-js-ripple-effect hdr-basket" href="<?php echo e(route('miCarrito')); ?>"><i class="fa fa-cart-plus"></i><span class="cart-count"><?php echo e(Session::has('carrito') ? Session::get('carrito')->cantidadTotal : ''); ?></span></a>
                                    
                                </li>
                                
                                <li class="mobile-menu-close"><i class="fa fa-times"></i></li>
                            </ul><!-- End Menu Section -->
                            <div id="menu-bar"><a><i class="fa fa-bars"></i></a></div>
                        </div>
                    </div>
                </div>
                <div class="search-bar animated zoomIn">
                    <div class="search-content">
                        <div class="search-input">
                            <input type="text" placeholder="¿Que estás Buscando?">
                            <button class="search-btn"><i class="icon-magnifier"></i></button>
                        </div>
                    </div>
                    <div class="search-close"><i class="icon-close"></i></div>
                </div>
            </div>
            <?php if(session('success')): ?>
                <div class="col-md-12 alert-success d-flex align-items-center justify-content-center" style="height: 10vh; font-size:1.5em; font-weight:600; ">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </header><!-- End Header Section -->
        <!-- Start Contact Popup -->
        <div id="contactPopup" class="modal fade">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Envianos tu Consulta</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row pb-4">
                            <form action="<?php echo e(route('nuevaConsulta')); ?>" method="post" style="width:100%;" class=" d-flex flex-wrap">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-6">
                                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label form-input">
                                        <input class="mdl-textfield__input" type="text" id="contact-name" name="nombre">
                                        <label class="mdl-textfield__label" for="contact-name">Tu nombre</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label form-input">
                                        <input class="mdl-textfield__input" type="text" id="contact-email" name="email">
                                        <label class="mdl-textfield__label" for="contact-email">Tu e-mail</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label form-input">
                                        <input class="mdl-textfield__input" type="text" id="contact-phone" name="celular">
                                        <label class="mdl-textfield__label" for="contact-phone">Tu Celular</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label form-input">
                                        <textarea class="mdl-textfield__input" rows="3" id="contact-message" name="mensaje"></textarea>
                                        <label class="mdl-textfield__label" for="contact-message">Mensaje</label>
                                    </div>
                                </div>
                                <div class="col-12 text-center">
                                    <button class="mdl-button mdl-js-button mdl-button--colored mdl-js-ripple-effect mdl-button--raised button button-success">Enviar Consulta</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End contact Popup -->

        


        




    <!-- **********Included Scripts*********** -->

   <?php echo $__env->make('partials._bottomScripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
