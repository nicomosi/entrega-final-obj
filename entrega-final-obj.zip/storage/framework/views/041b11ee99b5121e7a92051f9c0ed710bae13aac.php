    <!-- Jquery Library 2.1 JavaScript-->
    <script src="<?php echo e(url('assets/plugin/jquery/jquery-2.1.4.min.js')); ?>"></script>
    <!-- Popper JavaScript-->
    <script src="<?php echo e(url('assets/plugin/popper/popper.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript-->
    <script src="<?php echo e(url('assets/plugin/bootstrap/bootstrap.min.js')); ?>"></script>
    <!-- Modernizr Core JavaScript-->
    <script src="<?php echo e(url('assets/plugin/modernizr/modernizr.js')); ?>"></script>
    <!-- Animaateheading JavaScript-->
    <script src="<?php echo e(url('assets/plugin/animateheading/animateheading.js')); ?>"></script>
    <!-- Material Design Lite JavaScript-->
    <script src="<?php echo e(url('assets/plugin/material/material.min.js')); ?>"></script>
    <!-- Material Select Field Script -->
    <script src="<?php echo e(url('assets/plugin/material/mdl-selectfield.min.js')); ?>"></script>
    <!-- Flexslider Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/flexslider/jquery.flexslider.min.js')); ?>"></script>
    <!-- Owl Carousel Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/owl_carousel/owl.carousel.min.js')); ?>"></script>
    <!-- Scrolltofixed Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/scrolltofixed/jquery-scrolltofixed.min.js')); ?>"></script>
    <!-- Magnific Popup Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/magnific_popup/jquery.magnific-popup.min.js')); ?>"></script>
    <!-- WayPoint Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/waypoints/jquery.waypoints.min.js')); ?>"></script>
    <!-- CounterUp Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/counterup/jquery.counterup.js')); ?>"></script>
    <!-- masonry Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/masonry_pkgd/masonry.pkgd.min.js')); ?>"></script>
    <!-- SmoothScroll Plugin JavaScript-->
    <script src="<?php echo e(url('assets/plugin/smoothscroll/smoothscroll.min.js')); ?>"></script>
    <!--Custom JavaScript-->
    <script src="<?php echo e(url('dist/js/custom.js')); ?>"></script>
